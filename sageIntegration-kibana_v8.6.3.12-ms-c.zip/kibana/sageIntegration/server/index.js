"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "SageIntegrationPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.SageIntegrationPluginSetup;
  }
});
Object.defineProperty(exports, "SageIntegrationPluginStart", {
  enumerable: true,
  get: function () {
    return _types.SageIntegrationPluginStart;
  }
});
exports.plugin = plugin;
var _plugin = require("./plugin");
var _types = require("./types");
//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.

function plugin(initializerContext) {
  return new _plugin.SageIntegrationPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwbHVnaW4iLCJpbml0aWFsaXplckNvbnRleHQiLCJTYWdlSW50ZWdyYXRpb25QbHVnaW4iXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgU2FnZUludGVncmF0aW9uUGx1Z2luIH0gZnJvbSAnLi9wbHVnaW4nO1xuXG4vLyAgVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gIGFzIHdlbGwgYXMsIEtpYmFuYSBQbGF0Zm9ybSBgcGx1Z2luKClgIGluaXRpYWxpemVyLlxuXG5leHBvcnQgZnVuY3Rpb24gcGx1Z2luKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gIHJldHVybiBuZXcgU2FnZUludGVncmF0aW9uUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7IFNhZ2VJbnRlZ3JhdGlvblBsdWdpblNldHVwLCBTYWdlSW50ZWdyYXRpb25QbHVnaW5TdGFydCB9IGZyb20gJy4vdHlwZXMnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTtBQVNBO0FBUEE7QUFDQTs7QUFFTyxTQUFTQSxNQUFNLENBQUNDLGtCQUE0QyxFQUFFO0VBQ25FLE9BQU8sSUFBSUMsNkJBQXFCLENBQUNELGtCQUFrQixDQUFDO0FBQ3REIn0=