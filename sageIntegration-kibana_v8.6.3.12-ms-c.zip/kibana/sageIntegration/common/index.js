"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'sageIntegration';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'sage_integration';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnc2FnZUludGVncmF0aW9uJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdzYWdlX2ludGVncmF0aW9uJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQU8sTUFBTUEsU0FBUyxHQUFHLGlCQUFpQjtBQUFDO0FBQ3BDLE1BQU1DLFdBQVcsR0FBRyxrQkFBa0I7QUFBQyJ9